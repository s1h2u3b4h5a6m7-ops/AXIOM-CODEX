# Nifty 50 Complete Data Pack

**Generated:** July 2026  
**Source:** NSE India, Screener.in, Moneycontrol, Groww.in, TickerTape, Angel One, MoneyWorks4Me, Smart-Investing.in  
**Total Files:** 22  
**Contents:** 1 Excel workbook (4 sheets) + 9 JSON datasets + 5 web search results + 1 CSV + 6 screenshots

---

## 📊 File Inventory

### Primary Data: Excel Workbook
| File | Size | Description |
|------|------|-------------|
| `Nifty_50_Complete_Data.xlsx` | 15 KB | **Main compiled data** — 4 sheets with all 50 Nifty 50 stocks |

**Excel Sheet Breakdown:**
- **Sheet 1: "Nifty 50 Stocks"** — All 50 constituent stocks with: Rank, Company Name, NSE Symbol, Sector, Current Price, Day Change %, Index Weightage %, P/E Ratio, Market Cap (₹ Cr), Dividend Yield %
- **Sheet 2: "Sector Summary"** — 22 sectors with: Sector Name, Stock Count, Weightage %, Market Cap, Index Contribution %
- **Sheet 3: "Top Movers Today"** — Top 10 Gainers & Top 10 Losers with: Name, Price, Change %, Weightage %, P/E, Market Cap
- **Sheet 4: "Index Overview"** — Key metrics: NIFTY 50 Value, Day Change, 52W High/Low, P/E (TTM), P/B, Dividend Yield, Total Market Cap, No. of Stocks, Base Year/Value, Exchange

### Web Scraping Data: JSON Files
| File | Size | Source | Contents |
|------|------|--------|----------|
| `nifty_screener.json` | 51 KB | Screener.in | Top 25 stocks: Price, PE, Market Cap, Div Yield, Sales, Profit Growth, 3Y CAGR, Book Value, ROE |
| `nifty_mc_contrib.json` | 407 KB | Moneycontrol | ~50 stocks: Price, Change %, Index Point Contribution, Weightage % |
| `nifty_groww.json` | 345 KB | Groww.in | ~50 stocks: Market Cap, Price, Change %, Sector classification |
| `nifty_mw4m.json` | 810 KB | MoneyWorks4Me | Company fundamentals: PE, PBV, RoE, Debt ratios, management quality |
| `nifty_smart.json` | 288 KB | Smart-Investing.in | Sector returns, index constituents, historical performance |
| `nifty_ticker.json` | 1.2 MB | TickerTape.in | Returns data (1D/1W/1M/3M/6M/1Y/3Y/5Y), Growth metrics, PE, Market Cap |
| `nifty_angel.json` | 527 KB | Angel One | Stock list with prices, chart data, performance metrics |
| `nifty_indices.json` | 213 KB | NSE Official (indices.nifty.com) | Official constituent list, index details, CSV download link |

### Web Search Results: JSON Files
| File | Size | Query Topic |
|------|------|-------------|
| `nifty_search1.json` | 5.0 KB | Nifty 50 current market price, PE ratio, market cap |
| `nifty_search2.json` | 4.0 KB | NSE official Nifty 50 constituents and weightage |
| `nifty_search3.json` | 4.5 KB | Complete list with weightage, PE, returns from multiple sources |
| `nifty_search4.json` | 6.0 KB | CSV download links, constituent lists from official sources |
| `nifty_search5.json` | 5.5 KB | PE ratio, dividend yield, fundamental data sources |

### CSV Data
| File | Size | Description |
|------|------|-------------|
| `nifty50_list.csv` | 512 B | NSE official CSV download attempt (blocked by CDN — empty/failed) |

### Dashboard Screenshots
| File | Description |
|------|-------------|
| `nifty_dashboard.png` | Full dashboard screenshot — Overview tab |
| `qa_overview.png` | Overview tab with market stats, heatmap, sector performance |
| `qa_stocks.png` | Stocks tab — sortable table of all 50 stocks |
| `qa_sectors.png` | Sectors tab — pie chart and breakdown |
| `qa_movers.png` | Movers tab — gainers vs losers bar chart |
| `qa_mobile.png` | Mobile responsive view |

---

## 📈 Key Data Highlights

| Metric | Value |
|--------|-------|
| **Nifty 50 Index Value** | ~23,996 |
| **Total Market Cap** | ~₹183.89 Lakh Crore |
| **P/E Ratio (TTM)** | ~20.52 |
| **52-Week High** | ~26,373 |
| **52-Week Low** | ~22,183 |
| **Dividend Yield** | ~1.23% |
| **Number of Stocks** | 50 |
| **Number of Sectors** | 22 |
| **Exchange** | NSE (National Stock Exchange) |

### Top 5 Stocks by Weightage
| Rank | Company | Symbol | Weightage |
|------|---------|--------|-----------|
| 1 | HDFC Bank | HDFCBANK | 10.27% |
| 2 | Reliance Industries | RELIANCE | 7.81% |
| 3 | ICICI Bank | ICICIBANK | 5.39% |
| 4 | Bharti Airtel | BHARTIARTL | 5.37% |
| 5 | Larsen & Toubro | LT | 4.07% |

---

## 🔍 Data Sources & Methodology

All data was collected through web scraping and search from publicly available Indian stock market sources:

1. **Screener.in** — Fundamental analysis platform with PE, Market Cap, ROE data
2. **Moneycontrol** — Index point contribution, stock-level weightage data
3. **Groww.in** — Market cap rankings and sector classification
4. **TickerTape** — Multi-period return data and growth metrics
5. **Angel One** — Stock performance and chart data
6. **MoneyWorks4Me** — Company fundamentals and quality scores
7. **Smart-Investing.in** — Sector returns and index performance
8. **NSE Official (indices.nifty.com)** — Authoritative constituent list

The Excel workbook was compiled by cross-referencing data from multiple sources for maximum accuracy.

---

## ⚠️ Disclaimer

Data is collected from publicly available sources for educational and informational purposes only. **Not for financial or investment decisions.** Always verify from official NSE/BSE sources before making any trading decisions. Data may be delayed and does not reflect real-time market prices.

---

*Packaged by Z.ai Nifty 50 Explorer*
